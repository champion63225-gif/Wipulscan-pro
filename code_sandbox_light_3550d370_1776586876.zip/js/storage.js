/* ═══════════════════════════════════════════════════════════════
   SuperPrompt Studio – Storage Layer (Table API + localStorage)
   ═══════════════════════════════════════════════════════════════ */

const TABLE_PROMPTS  = 'superprompt_saved';
const TABLE_HISTORY  = 'superprompt_history';
const LS_HISTORY_KEY = 'sps_history';
const LS_CONFIG_KEY  = 'sps_last_config';

/* ─── Table API Helpers ─── */
async function apiGet(table, params = {}) {
  const qs = new URLSearchParams(params).toString();
  const url = `tables/${table}${qs ? '?' + qs : ''}`;
  const res = await fetch(url);
  if (!res.ok) throw new Error(`GET ${url} → ${res.status}`);
  return res.json();
}

async function apiPost(table, data) {
  const res = await fetch(`tables/${table}`, {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(data),
  });
  if (!res.ok) throw new Error(`POST tables/${table} → ${res.status}`);
  return res.json();
}

async function apiDelete(table, id) {
  const res = await fetch(`tables/${table}/${id}`, { method: 'DELETE' });
  if (!res.ok && res.status !== 204) throw new Error(`DELETE tables/${table}/${id} → ${res.status}`);
}

/* ─── Saved Prompts ─── */
async function loadSavedPrompts(search = '', category = '') {
  try {
    const params = { limit: 200 };
    if (search)   params.search = search;
    const result = await apiGet(TABLE_PROMPTS, params);
    let rows = result.data || [];
    if (category) rows = rows.filter(r => r.category === category);
    return rows.sort((a, b) => (b.created_at || 0) - (a.created_at || 0));
  } catch (e) {
    console.warn('loadSavedPrompts error:', e);
    return [];
  }
}

async function savePrompt(data) {
  return apiPost(TABLE_PROMPTS, {
    name:        data.name,
    category:    data.category,
    tags:        data.tags,
    note:        data.note,
    prompt_text: data.prompt_text,
    config_json: JSON.stringify(data.config || {}),
    char_count:  data.prompt_text ? data.prompt_text.length : 0,
  });
}

async function deletePrompt(id) {
  return apiDelete(TABLE_PROMPTS, id);
}

/* ─── History (localStorage) ─── */
function loadHistory() {
  try {
    return JSON.parse(localStorage.getItem(LS_HISTORY_KEY) || '[]');
  } catch { return []; }
}

function saveHistory(items) {
  localStorage.setItem(LS_HISTORY_KEY, JSON.stringify(items.slice(0, 100)));
}

function addHistoryEntry(entry) {
  const history = loadHistory();
  history.unshift({
    id:        'h_' + Date.now(),
    title:     entry.title || 'Generierter Prompt',
    preview:   entry.preview || '',
    prompt:    entry.prompt || '',
    config:    entry.config || {},
    timestamp: Date.now(),
  });
  saveHistory(history);
  return history;
}

function clearHistory() {
  localStorage.removeItem(LS_HISTORY_KEY);
}

/* ─── Last Config (localStorage) ─── */
function saveLastConfig(config) {
  localStorage.setItem(LS_CONFIG_KEY, JSON.stringify(config));
}

function loadLastConfig() {
  try {
    return JSON.parse(localStorage.getItem(LS_CONFIG_KEY));
  } catch { return null; }
}
